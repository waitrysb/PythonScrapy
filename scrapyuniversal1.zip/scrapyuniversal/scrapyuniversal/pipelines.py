# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymysql
from scrapy import Request
from scrapy.exceptions import DropItem
from scrapyuniversal.utils import fix_format

class MojiPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		del(data['table'])
		keys = ', '.join(data.keys())
		values = ', '.join(['%s'] * len(data))
		sql = "REPLACE into %s (%s) values (%s)" % (item["table"], keys, values)
		try:
			self.cursor.execute(sql, tuple(data.values()))
			self.db.commit()
		except:
			print('Error')
		return item

class DamaiMainPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		insert_sql = "INSERT INTO Activaty_on_Damai(projectid,name,showstatus,actors,categoryname,subcategoryname,description,subhead,favourable,favourites,price_low,price_high,venue,venuecity,showtime_start,showtime_end,update_date) VALUES (%s,'%s','%s','%s','%s','%s','%s','%s','%s','%s',%s,%s,'%s','%s','%s','%s','%s')"
		insert_sql = insert_sql%(str(data['projectid']),fix_format(data['nameNoHtml']),fix_format(data['showstatus']),fix_format(data['actors']),\
								fix_format(data['categoryname']),fix_format(data['subcategoryname']),fix_format(data['description']),fix_format(data['subhead']),fix_format(data['favourable']),str(data['favourites']),str(data['price_low']),str(data['price_high']),\
								fix_format(data['venue']),fix_format(data['venuecity']),fix_format(data['showtime_start']),fix_format(data['showtime_end']),data['update_date'])
		insert_sql = insert_sql.replace("'None'",'NULL')
		insert_sql = insert_sql.replace('None','NULL')
		try:
			self.cursor.execute(insert_sql)
		except pymysql.Error as e:
			# 如果主键已存在，则更新主键以外的属性
			if e.args[0] == 1062:
				update_sql = "UPDATE Activaty_on_Damai SET name='%s',showstatus='%s',actors='%s',categoryname='%s',subcategoryname='%s',description='%s',subhead='%s',favourable='%s',favourites=%s,price_low=%s,price_high=%s, venue='%s',venuecity='%s',showtime_start='%s',showtime_end='%s',update_date='%s' where projectid ='%s'"\
							%(fix_format(data['nameNoHtml']), fix_format(data['showstatus']), fix_format(data['actors']),\
						fix_format(data['categoryname']),fix_format(data['subcategoryname']),fix_format(data['description']),fix_format(data['subhead']),fix_format(data['favourable']),str(data['favourites']),str(data['price_low']),str(data['price_high']),\
						fix_format(data['venue']),fix_format(data['venuecity']),fix_format(data['showtime_start']),fix_format(data['showtime_end']),data['update_date'],str(data['projectid']))
				update_sql = update_sql.replace("'None'",'NULL')
				update_sql = update_sql.replace('None','NULL')
				try:
					self.cursor.execute(update_sql)
				except pymysql.Error as e:
					print('update fail================================\n',str(e),update_sql)
			else:
				print('insert fail================================\n',str(e),insert_sql)
		self.db.commit()
		return item

class DamaiPagePipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		update_sql = "UPDATE Activaty_on_Damai SET price_all='%s',showtimes='%s',update_date='%s' WHERE projectid ='%s'" % (data['price_all'], data['show_times'], data['update_date'], data['projectid'])
		update_sql = update_sql.replace("'null'",'NULL')
		try:
			self.cursor.execute(update_sql)
		except Exception as e:
			print(str(e),update_sql)
		self.db.commit()
		return item

class DamaiAddrPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		update_sql = "UPDATE Activaty_on_Damai SET nearest_station='%s',lat=%f,lng=%f,update_date='%s' where projectid=%d" % (data['station_name'],data['lat'],data['lng'],data['update_date'],data['proj_id'])
		update_sql = update_sql.replace("'null'",'NULL')
		try:
			self.cursor.execute(update_sql)
		except Exception as e:
			print(str(e),update_sql)
		self.db.commit()
		return item


class QingtingPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		content = dict(item)
		sql = "SELECT * FROM audio WHERE id = '%s'"
		try:
			self.cursor.execute(sql%(content['id']))
			result = self.cursor.fetchone()
			if(result == None):
				sql = "INSERT INTO audio(title, cover, description, id, playcount, score, type, category, update_time, page, m4a_url, m4a_num) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" 
				try:
					self.cursor.execute(sql%(content['title'], content['cover'], content['description'], content['id'], content['playcount'], content['score'], content['type'], content['category'], content['update_time'], str(content['page']), content['m4a_url'], content['m4a_num']))
					self.db.commit()
				except:
					self.db.rollback()
			else:
				sql = "select m4a_url, m4a_num from audio WHERE id ='%s'"
				self.cursor.execute(sql%(content['id']))
				result = self.cursor.fetchone()
				num = int(result[1])
				url = result[0]
				temp = url
				urls = url.split('+')
				item_url = content['m4a_url'].split('+')
				for uu in item_url:
					if uu in urls:
						num+=1
						temp = temp + "+" + uu
				sql = "update audio set m4a_url='%s', m4a_num='%s' where id='%s'" 
				try:
					self.cursor.execute(sql%(temp, str(num), content['id']))
					self.db.commit()
				except:
					self.db.rollback()
		except:
			print("Error")
		return item

class WeiboWinPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		del(data['table'])
		keys = ', '.join(data.keys())
		values = ', '.join(['%s'] * len(data))
		sql = "insert into %s (%s) values (%s)" % (item["table"], keys, values)
		try:
			self.cursor.execute(sql, tuple(data.values()))
			self.db.commit()
		except:
			print('Error')
		return item

class DianPingPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		# data = dict(item)
		# insert_sql = "INSERT INTO Dish_of_Shop_GZ (dish_id, shop_id, price, rec_cnt, dish_name, picture_url, update_date) VALUES (%s, %s, %s, %s, '%s', '%s', '%s')"\
		# 		% (data['dish_id'], data['shop_id'], data['price'], data['rec_cnt'], data['dish_name'], data['picture_url'], data['update_date'])
		# insert_sql = insert_sql.replace("'None'",'NULL')
		# insert_sql = insert_sql.replace('None','NULL')
		# try:
		# 	self.cursor.execute(insert_sql)
		# except pymysql.Error as e:
		# 	# 如果主键已存在，则更新主键以外的属性
		# 	if e.args[0] == 1062:
		# 		update_sql = "UPDATE Dish_of_Shop_GZ SET shop_id=%s ,price=%s, rec_cnt=%s, dish_name='%s', picture_url='%s', update_date='%s' WHERE dish_id=%s"\
		# 				%(data['shop_id'], data['price'], data['rec_cnt'], data['dish_name'], data['picture_url'], data['update_date'], data['dish_id'])
		# 		update_sql = update_sql.replace("'None'",'NULL')
		# 		update_sql = update_sql.replace('None','NULL')
		# 		try:
		# 			self.cursor.execute(update_sql)
		# 		except MySQLdb.Error as e:
		# 			print('update fail================================\n',str(e),update_sql)
		# 	else:
		# 		print('insert fail================================\n',str(e),insert_sql)
		# self.db.commit()
		print('process')
		return item

class TrainNumPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()
		sql = "truncate table train_num_info"
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		keys = ', '.join(data.keys())
		values = ', '.join(data.values())
		sql = "insert into %s(%s) values (%s)" % ('train_num_info', keys, values)
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')
		return item

class TrainStationPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()
		sql = "truncate table train_station_info"
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		keys = ', '.join(data.keys())
		values = ', '.join(data.values())
		sql = "insert into %s(%s) values (%s)" % ('train_station_info', keys, values)
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')
		return item

class CountryInfoPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()
		# sql = "truncate table country_info"
		# try:
		# 	self.cursor.execute(sql)
		# 	self.db.commit()
		# except:
		# 	print('Error')

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		keys = ', '.join(data.keys())
		values = ', '.join(data.values())
		sql = "insert into %s(%s) values (%s)" % ('country_info', keys, values)
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')
		return item

class CityInfoPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()
		# sql = "truncate table city_info"
		# try:
		# 	self.cursor.execute(sql)
		# 	self.db.commit()
		# except:
		# 	print('Error')

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		keys = ', '.join(data.keys())
		values = ', '.join(data.values())
		sql = "insert into %s(%s) values (%s)" % ('city_info', keys, values)
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')
		return item

class IPInfoPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()
		sql = "truncate table ip_info"
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		keys = ', '.join(data.keys())
		values = ', '.join(data.values())
		sql = "insert into %s(%s) values (%s)" % ('ip_info', keys, values)
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')
		return item

class SceneInfoPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()
		# sql = "truncate table scene_info"
		# try:
		# 	self.cursor.execute(sql)
		# 	self.db.commit()
		# except:
		# 	print('Error')

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		keys = ', '.join(data.keys())
		values = ', '.join(data.values())
		sql = "insert into %s(%s) values (%s)" % ('scene_info', keys, values)
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')
		return item

class SceneDetailPipeline(object):
	def __init__(self, host, database, user, password, port):
		self.host = host
		self.database = database
		self.user = user
		self.password = password
		self.port = port

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			host = crawler.settings.get('MYSQL_HOST'),
			database = crawler.settings.get('MYSQL_DATABASE'),
			user = crawler.settings.get('MYSQL_USER'),
			password = crawler.settings.get('MYSQL_PASSWORD'),
			port = crawler.settings.get('MYSQL_PORT')
		)

	def open_spider(self, spider):
		self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
		self.cursor = self.db.cursor()

	def close_spider(self, spider):
		self.db.close()

	def process_item(self, item, spider):
		data = dict(item)
		sql = "update scene_info set "
		first = True
		for key in data.keys():
			if key != "id":
				if first:
					first = False
				else:
					sql += ', '
				sql += key + '=' + str(data[key]) + ' '
		sql += 'where id=' + str(data['id'])
		try:
			self.cursor.execute(sql)
			self.db.commit()
		except:
			print('Error')
		return item


class ToutiaoNewsPipeline(object):
	def __init__(self, path):
		self.path = path
		self.file_dict = {}
		self.file = open(path + 'news.csv', 'a', encoding='utf-8')

	@classmethod
	def from_crawler(cls, crawler):
		return cls(
			path = crawler.settings.get('FILE_PATH')
		)

	def open_spider(self, spider):
		self.count = 0
		self.last_count = 0

	def close_spider(self, spider):
		for key in self.file_dict.keys():
			#self.file_dict[key].flush()
			#self.file_dict[key].close()
			print(key + ': ' + str(self.file_dict[key]))
		self.file.close()

	def process_item(self, item, spider):
		data = dict(item)
		if data['category'] not in self.file_dict.keys():
			#f = open(self.path + data['category'] + '.csv', 'a', encoding='utf-8')
			#self.file_dict[data['category']] = f
			self.file_dict[data['category']] = 0
		news = ""
		first = True
		for key in data.keys():
			if first == False:
				news += "_|_"
			else:
				first = False
			news += str(data[key])
		try:
			#self.file_dict[data['category']].write(news + '\n')
			self.file_dict[data['category']] = self.file_dict[data['category']] + 1
			self.file.write(news + '\n')

			self.count += 1
			if self.count - self.last_count >= 500:
				self.last_count = self.count
				print('all: ' + str(self.count))
				for key in self.file_dict.keys():
					print(key + ': ' + str(self.file_dict[key]))
					#self.file_dict[key].flush()
				self.file.flush()
		except:
			print('Error')
		return item



