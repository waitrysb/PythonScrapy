# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/spider-middleware.html

from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from scrapy.http import HtmlResponse
from logging import getLogger
import time
import random
from scrapy import signals
from scrapy.downloadermiddlewares.useragent import UserAgentMiddleware

from scrapyuniversal.items import *
from scrapyuniversal.utils import getProxies
import pymysql
import re
from selenium.common.exceptions import NoSuchElementException
import requests
from PIL import Image

import base64
class ScrapyuniversalSpiderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, dict or Item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Response, dict
        # or Item objects.
        pass

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)


class WeiboWinDownloaderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.
    def __init__(self, timeout=None, service_args=[]):
        self.logger = getLogger(__name__)
        self.timeout = timeout
        #self.browser = webdriver.PhantomJS(service_args=service_args, executable_path=r'C:\Program Files\Anaconda3\phantomjs-2.1.1-windows\bin\phantomjs.exe')
        self.browser = webdriver.Chrome()
        self.browser.set_window_size(1400, 700)
        self.browser.set_page_load_timeout(self.timeout)
        self.wait = WebDriverWait(self.browser, self.timeout)

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        return cls(timeout=crawler.settings.get('SELENIUM_TIMEOUT'), service_args=crawler.settings.get('PHANTOMJS_SERVICE_ARGS'))

    def process_request(self, request, spider):
        self.logger.debug('Chrome is Starting')
        username = request.meta.get('userName')
        password = request.meta.get('passWord')

        try:
            self.browser.get(request.url)
            userid = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, '#userId')))
            passwd = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, '#passwd')))
            submit = self.wait.until(
                EC.element_to_be_self.clickable((By.CSS_SELECTOR, 'div.oauth_login_submit p.oauth_formbtn > a.WB_btn_login')))

            userid.clear()
            userid.send_keys(username)
            passwd.clear()
            passwd.send_keys(password)
            submit.self.click()
            #time.sleep(self.timeout)
            self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '#form #kw')))

            url = self.browser.current_url
            self.logger.debug('Chrome is ending')
            return HtmlResponse(url=url, body=self.browser.page_source, request=request, encoding='utf-8',
                                status=200)
        except TimeoutException:
            self.logger.debug('Chrome is error')
            return HtmlResponse(url=request.url, status=500, request=request)


    def __del__(self):
        #self.browser.close()
        pass

class RotateUserAgentMiddleware(UserAgentMiddleware):
    def __init__(self, user_agent=''):
        self.user_agent = user_agent
 
    def process_request(self, request, spider):
        ua = random.choice(self.user_agent_list)
        if ua:
            print (ua, '-----------------yyyyyyyyyyyyyyyyyyyyyyyyy')
            request.headers.setdefault('User-Agent', ua)
 
    #the default user_agent_list composes chrome,I E,firefox,Mozilla,opera,netscape
    #for more user agent strings,you can find it in http://www.useragentstring.com/pages/useragentstring.php
    user_agent_list = [\
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1"\
        "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",\
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",\
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",\
        "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",\
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",\
        "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5",\
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",\
        "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",\
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",\
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",\
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",\
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",\
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",\
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",\
        "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3",\
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",\
        "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24"
       ]

class ProxyMiddleware(object):
    '''
    设置Proxy
    '''

    def __init__(self, ip):
        self.ip = ip

    @classmethod
    def from_crawler(cls, crawler):
        proxies = getProxies()
        return cls(ip=proxies)

    def process_request(self, request, spider):
        proxy = random.choice(self.ip)
        print("this is request ip:"+proxy)  
        request.meta['proxy'] = proxy

    def process_response(self, request, response, spider):  
        '''对返回的response处理'''  
        # 如果返回的response状态不是200，重新生成当前request对象  
        if response.status != 200:  
            proxy = random.choice(self.ip)
            print("this is request ip:"+proxy)
            # 对当前request加上代理  
            request.meta['proxy'] = proxy   
            return request
        return response  

class DianPingDownloaderMiddleware(object):
  
    def __init__(self,host, database, user, password, port,timeout=None, service_args=[]):
        self.logger = getLogger(__name__)
        self.timeout = timeout
        #self.browser = webdriver.PhantomJS(service_args=service_args, executable_path=r'C:\Program Files\Anaconda3\phantomjs-2.1.1-windows\bin\phantomjs.exe')
        options = webdriver.ChromeOptions()
        #1允许所有图片；2阻止所有图片；3阻止第三方服务器图片
        prefs = {
        'profile.default_content_setting_values': {
            'images': 1
            }
        }
        options.add_argument('lang=zh_CN.UTF-8')
        options.add_argument('disable-infobars')
        ###
        options.add_argument('--disable-extensions')
        options.add_argument('--profile-directory=Default')
        options.add_argument("--incognito")
        options.add_argument("--disable-plugins-discovery");
        options.add_argument("--start-maximized")
        options.add_argument("--proxy-server=http://127.0.0.1:8001")

        options.add_experimental_option('prefs', prefs)

        options.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.92 Safari/537.36')
        #options.add_argument('user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1')
        #options.add_argument('user-agent=Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6')
        cookie = {
            'JSESSIONID':'850BDC90D8BB7A5DA5C1B59AD459DF0A',
            '_hc.v':'"\"4129f769-f160-4c9d-a970-bdc437fc42dc.1511684578\"',
            '_lx_utm':'utm_source%3DBaidu%26utm_medium%3Dorganic',
            '_lxsdk':'15ff76c2d4ec8-064039c6a9e111-3970065f-1fa400-15ff76c2d4eaf',
            '_lxsdk_cuid':'15ff76c2d4ec8-064039c6a9e111-3970065f-1fa400-15ff76c2d4eaf',
            '_lxsdk_s':'16120afd727-92b-871-8cb%7C%7C30',
            'aburl':'1',
            'cityid':'2',
            'ctu':'1740b39cddeded7cd35eff913b962d845c957b009e1935abd2b1c40da083c352',
            'cy':'4',
            'cye':'guangzhou',
            'll':'7fd06e815b796be3df069dec7836c3df',
            'navCtgScroll':'0',
            'pvhistory':'"6aaW6aG1Pjo8Lz46PDE1MTU1NDk5Nzk4ODldX1s="',
            's_ViewType':'10',
            'source':'m_browser_test_33',
            'switchcityflashtoast':'1',
            'ua':'dpuser_0216512946'
        }
#executable_path="D:\\geckodriver"
        self.browser = webdriver.Chrome(chrome_options=options, desired_capabilities = None, executable_path="C:\\Users\\晟\\Desktop\\chromedriver.exe") 
        self.browser.delete_all_cookies()
        self.browser.set_window_size(800,800)
        self.browser.set_window_position(0,0)
        #self.browser = webdriver.Chrome()
        #self.browser.set_window_size(1400, 700)
        self.browser.set_page_load_timeout(self.timeout)
        self.wait = WebDriverWait(self.browser, self.timeout)

        self.host = host
        self.database = database
        self.user = user
        self.password = password
        self.port = port
        self.db = pymysql.connect(self.host, self.user, self.password, self.database, charset='utf8', port=self.port)
        self.cursor = self.db.cursor()

        self.load_cnt = 0 #计数


    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        return cls(
            timeout=crawler.settings.get('SELENIUM_TIMEOUT'),
            service_args=crawler.settings.get('PHANTOMJS_SERVICE_ARGS'),
            host = crawler.settings.get('MYSQL_HOST'),
            database = crawler.settings.get('MYSQL_DATABASE'),
            user = crawler.settings.get('MYSQL_USER'),
            password = crawler.settings.get('MYSQL_PASSWORD'),
            port = crawler.settings.get('MYSQL_PORT')
         )

    def process_request(self, request, spider):
        self.logger.debug('Chrome is Starting')

        dish_i_start, subway_i_start, station_i_start, crt_page_start, shop_i_start =1, 4, 14, 2, 0
        restart_flag = True
        driver = self.browser
        url = "http://10.108.122.5:5000/base64"
        #没有1
        #class2num = {"zogwtn": 0, "zogtr3": 7, "zogom2": 8, "zoggdp": 4, "zog0xa": 2, 'zog6h6': 3, 'zogdwl':9, "zogf54": 6, "zoggvv": 5}
        #class2num = {"vhk08k": 0, "vhkqsc": 7, "vhkjj4": 8, "vhkj5t": 4, "vhk9or": 2, 'vhk2ll': 3, 'vhk2pi':9, "vhkvxd": 6, "vhk84t": 5}
        #class2num = {"pzcqzc": 0, "pzcinw": 7, "pzcp9y": 8, "pzc7k1": 4, "pzct4n": 2, 'pzc5pv': 3, 'pzcdx5':9, "pzccub": 6, "pzcxyq": 5}
        class2num = {"eu6g8": 0, "eu1n1": 7, "euyzz": 8, "euxjq": 4, "eui9y": 2, 'euakg': 3, 'eucb0':9, "eua80": 6, "eumk1": 5}
        #self.browser.get(request.url)
        try:
            driver.get(request.url)
            self.click(driver.find_element_by_xpath('//*[@id="J_nc_business"]/div[1]/ul/li[1]'))
        except TimeoutException:  
            print ('time out after 30 seconds when loading page' ) 
            driver.execute_script('window.stop()')


        #time.sleep(60*3)
        # dish类 classfy
        dish_cnt = len(driver.find_element_by_xpath('//div[@id="classfy"]').find_elements_by_css_selector("a"))
        more = False
        if driver.find_element_by_xpath('//*[@id="classfy"]/a[%d]' % dish_cnt).get_attribute('href').strip() == 'javascript:;':
            dish_cnt = dish_cnt - 1
            more = True

        for dish_i in range(dish_cnt):

            dish_i = dish_i + 1

            if dish_i < dish_i_start:
                continue

            if more == True:  # click more
                self.click(driver.find_element_by_xpath('//*[@id="classfy"]/a[%s]' % str(dish_cnt+1)))

            try:
                self.click(driver.find_element_by_xpath('//*[@id="classfy"]/a[%d]' % dish_i)) #dish click
            except:
                self.click(driver.find_element_by_xpath('//*[@id="classfy"]/a[%s]' % str(dish_cnt+1)))
                self.click(driver.find_element_by_xpath('//*[@id="classfy"]/a[%d]' % dish_i))

            # 菜品id
            dish_id = driver.find_element_by_xpath('//*[@id="classfy"]/a[%d]' % dish_i).text

            if len(driver.find_elements_by_xpath('//*[@id="J_nav_tabs"]/a')) < 3:
                continue

            self.click(driver.find_element_by_xpath('//*[@id="J_nav_tabs"]/a[3]')) #//地铁线
            #// 几号线
            subway_line_cnt = len(driver.find_element_by_xpath('//*[@id="metro-nav"]').find_elements_by_css_selector("a"))
            





            for subway_i in range(subway_line_cnt):
                subway_i += 1
                if restart_flag and subway_i < subway_i_start: # ctrl subway line
                    continue
                print ('subway_i =', subway_i,'='*20)
                self.click(driver.find_element_by_xpath('//*[@id="metro-nav"]/a[%d]'%subway_i)) #choose subway line

                station_cnt = self.load_elem('//*[@id="metro-nav-sub"]')    ## 站点
                station_cnt = len(station_cnt.find_elements_by_css_selector("a"))
                time.sleep(4)
                station_more = False
            #     station_cnt = len(driver.find_element_by_xpath('//*[@id="metro-nav-sub"]').find_elements_by_css_selector("a"))    
                tmp = driver.find_element_by_xpath('//*[@id="metro-nav-sub"]/a[%d]'%station_cnt)
                if tmp.get_attribute('href').strip() == 'javascript:;':  # more
                    self.click(tmp)
                    station_more = True
                    station_cnt -= 1
                    print('more station')


                # 站点递归
                for station_i in range(station_cnt-1):
                    station_i+=2
                    if restart_flag and station_i < station_i_start: # ctrl station
                        continue
                    if station_more == True:
                        print('click more')
                        self.click(driver.find_element_by_xpath('//*[@id="metro-nav-sub"]/a[%s]' % str(station_cnt+1)))

                    station_elem = self.load_elem('//*[@id="metro-nav-sub"]/a[%s]'%station_i)

                    print ('station_i =',station_i,'='*10)
            #         parse shop
                    dp_id = station_elem.get_attribute('href')
                    dp_id = dp_id[dp_id.rfind('/')+1:]             #站点 id

                    crt_station_name = station_elem.find_element_by_tag_name('span').text #站点名字

                    try:
                        self.click(station_elem)
                    except:
                        self.click(driver.find_element_by_xpath('//*[@id="metro-nav-sub"]/a[%s]' % str(station_cnt+1)))
                        self.click(station_elem)
                    #self.click(driver.find_element_by_xpath('/html/body/div[2]/div[2]/div[2]/a[1]')) # 1km
                    shop_list_handle = driver.current_window_handle
                    crt_page = 0
    #################################################
                    while(True):
                        crt_page += 1
                        print ('page_i = ', crt_page, '==========')
                        if restart_flag and crt_page < crt_page_start: # ctrl page
                            try:         
                                self.click(driver.find_element_by_class_name('next'))
                            except:
                                print('页数超标')
                                break
            #                 except NoSuchElementException as e:
            #                     continue
            #                 finally:
                            continue

                        self.random_scoll(3)
                        #    shop page
                        for shop_i, e in enumerate(driver.find_element_by_xpath('//*[@id="shop-all-list"]/ul').find_elements_by_css_selector("li")):
                            shop_i +=1 
                            
                            if restart_flag and shop_i < shop_i_start:

                             # ctrl shop order
                                continue
                            
                            restart_flag = False
                            
                            time.sleep(5) ##30

                            self.click(e.find_element_by_xpath('//*[@id="shop-all-list"]/ul/li[%d]/div[1]'%shop_i)) # choose shop
                            shop_home_page_handle = driver.window_handles[1]
                            driver.switch_to.window(shop_home_page_handle)

                            shop_id = driver.current_url
                            #dp_id.rfind('/')+1:
                            shop_id = shop_id[shop_id.rfind('/')+1:]

                            
                            verify_times = 0
                            #验证码处理
                            while('verify.meituan.com' in driver.current_url and 
                                  verify_times < 500):
                                #send_email(u"DP 爬虫出 bug 了!!!"  ,u'救命! 快帮我输验证码:\n '+driver.current_url)
                                print('------------------------------------------------bug')
                                verify_times += 1
            #                     time.sleep(20 * 60 * verify_times)
                                verify_img = 0
                                try:
                                    while verify_img<5 and 'verify.meituan.com' in driver.current_url:
                                        time.sleep(8)

                                        driver.save_screenshot('code.png')
                                        element = driver.find_element_by_xpath('//img[@id="yodaImgCode"]')
                                        left = element.location['x']
                                        top = element.location['y']
                                        right = element.location['x'] + element.size['width']
                                        bottom = element.location['y'] + element.size['height']
                                        im = Image.open('code.png') 
                                        im = im.crop((left, top, right, bottom))
                                        im.save('code.png')
                                        imgStr = None
                                        with open("code.png", 'rb') as f:
                                            base64_data = base64.b64encode(f.read())
                                            imgStr = base64_data.decode()
                                        
                                        data = {'data': imgStr}
                                        html = requests.post(url, data).text

                                        inputImg = driver.find_element_by_xpath('//div[@class="_image__wrapper___1iO97 "]/input[@id="yodaImgCodeInput"]')
                                        inputImg.send_keys(html)
                                        print('html --------------------------------------',verify_img,'===', html)
                                        Button = driver.find_element_by_xpath('//Button[@id="yodaNextImgCode"]')
                                        #print(html)
                                        ##
                                        self.click(Button)
                                        verify_img +=1
                                except:
                                    time.sleep(5)

                                time.sleep(5)
                                ## 返回列表页面
                                driver.close()
                                time.sleep(2)
                                driver.switch_to.window(shop_list_handle)
                                self.click(e.find_element_by_xpath('//*[@id="shop-all-list"]/ul/li[%d]/div[1]'%shop_i)) # choose shop
                                shop_home_page_handle = driver.window_handles[1]
                                driver.switch_to.window(shop_home_page_handle)
                                print ('verify_times =', verify_times)
                                
                            
            #                 print 'shop_home_page_handle', shop_home_page_handle
                            #self.random_scoll(3)
            #                 prase shop page                
                            ###################################################     
                            #store_shop_extra_info(int(driver.current_url[driver.current_url.rfind('/')+1:]))
                            print('store shop =========================================')
                            #taste, env, service = self.getInfo(driver, class2num)


                            time.sleep(8)
                            #shop-name
                            item = driver.find_elements_by_xpath('//div[@id="shop-tabs"]/h2/a')
                            itemNext = False
                            for i in item :
                                #data-click-name="官方相册"
                                if i.get_attribute('data-click-name') == '官方相册':
                                    itemNext = True

                            if itemNext == True:

                                title = driver.find_element_by_xpath('//h1[@class="shop-name"]').get_attribute('innerHTML')
                                title = title[:title.index('<')].strip()
                                #print(title, '+'*23)
                                # 均价
                                taste, env, service = self.getInfo(driver, class2num)

                                #lat lng
                                img = self.load_elem('//*[@id="map"]/img')

                                if img == None:
                                    driver.refresh()
                                    img = self.load_elem('//*[@id="map"]/img')

                                if img == None:
                                    print('map fail', title)
                                    continue

                                imgstring = img.get_attribute('src').split('|')[1].split(',')
                                lat = imgstring[0]
                                lng = imgstring[1]
                                # photo list
                                imglist = []

                                infoSql = [shop_id, title, dish_id, lat, lng, crt_station_name, taste, env, service]
                                try:
                                    print(infoSql)
                                except:
                                    print('编码问题')
                                
                                #官方相册
                                item = driver.find_elements_by_xpath('//div[@id="shop-tabs"]/h2/a')
                                for i in item :
                                    #data-click-name="官方相册"
                                    if i.get_attribute('data-click-name') == '官方相册':
                                        print ('guanfang----------------------')
                                        i.click()
                                        time.sleep(5)
                                        imgdiv = driver.find_elements_by_xpath('//div[@id="shop-tabs"]/div[@class="shop-tab-photos clearfix J-panel"]/div[@class="container clearfix"]/div[@class="item"]')
                                        
                                        for i in range(len(imgdiv)):
                                            imgdiv[i].click()
                                            img_handle = driver.window_handles[2]
                                            driver.switch_to.window(img_handle)

                                            while(True):
                                                self.random_scoll(3)

                                                imgEle = self.load_elem('//div[@id="J_pic-wrap"]/div[@class="cursor-right"]/img')
                                                if imgEle == None:
                                                    print('title="没有下一张啦"')
                                                    imgEle = self.load_elem('//div[@id="J_pic-wrap"]//div[@title="没有下一张啦"]/img')
                                                try:
                                                    imglist.append(imgEle.get_attribute("src"))
                                                except:
                                                    print("img 找不到")
                                                #print(len(imglist))
                                                nextEle = self.load_elem('//div[@class="slide-nav"]/span[3]')
                                                try:
                                                    if 'disable' in nextEle.get_attribute('class'):
                                                        break
                                                    else:
                                                        nextEle.click()
                                                except:
                                                    break

                                            driver.close()
                                            driver.switch_to.window(shop_home_page_handle)

                                        print('img finifsh', '+'*20)
                                if len(imglist) > 0:
                                    self.ImgInfoStorage(shop_id ,imglist)
                                    self.BaseInfoStorage(infoSql)
                                
                            driver.close()
                            driver.switch_to.window(shop_list_handle)

                        try:         
                            self.click(driver.find_element_by_class_name('next'))
                        except NoSuchElementException as e:
                            break




        # query_sql = "SELECT projectid FROM Activaty_on_Damai limit 10"
        
        # self.cursor.execute(query_sql)
        # results = self.cursor.fetchall()
        # for item in results:
        #     print(item)
        #     print('------------------------------------------------')
        #     break
        # self.db.close()
        return HtmlResponse(url=request.url, body=self.browser.page_source, request=request, encoding='utf-8',
                                 status=200)



    def __del__(self):
        #self.browser.close()
        pass

    #
    def getInfo(self, driver ,class2num):
        Eles = driver.find_elements_by_xpath('//span[@id="comment_score"]/span')
        Eleinfo = []

        for i in Eles:
            eleString = i.get_attribute('innerHTML')

            for k, item in class2num.items():
                eleString = re.sub('<d class="'+k+'"></d>', str(item), eleString)

            eleString = ''.join(list(filter(lambda ch: ch in '0123456789.', eleString)))
            Eleinfo.append(eleString)

        # avgEle = driver.find_element_by_xpath('//*[@id="' + tag + '"]')
        # avgString = avgEle.get_attribute('innerHTML')

        # for i, item in class2num.items():
        #     avgString = re.sub('<d class="'+i+'"></d>', str(item), avgString)

        # for i in  outlist:
        #     avgString = avgString.replace(i, '')

        return Eleinfo[0], Eleinfo[1], Eleinfo[2]

        

        return avg

    def click(self, elem):
        try:
            elem.click()
        except TimeoutException:  
            print('time out after 30 seconds when loading page')
            driver.execute_script('window.stop()')

        self.load_cnt += 1
        if self.load_cnt < 2:
            time.sleep(16)
    #         return
    # #     time.sleep(3)
    #     if self.load_cnt % 200 == 0: #30
    #         time.sleep(7*60)
        else:
            time.sleep(10)
        
    def exe_sql(self, sql):
    #     print 'exe_sql =', sql
    #     return None
        global cursor
        
        try:
            db.ping()
        except:
            db.ping(True)

    #     print(sql)
        cursor.execute(sql)
        return cursor.fetchall()



    def load_elem(self, xpath_str):
        elem = None
        try:
            elem = self.wait.until(
                EC.presence_of_element_located((By.XPATH, xpath_str))
                )
        finally:
            return elem
        
    def random_scoll(self, s):
        for i in range(s//2):
            if i%2 == 0:
                self.browser.execute_script('window.scrollTo(0,document.body.scrollHeight)')
            else:
                self.browser.execute_script('window.scrollTo(document.body.scrollHeight,0)')
            time.sleep(2)   

    def BaseInfoStorage(self, infoList):
        userful_columns = ['shopId', 'shopName', 'shopStyle', 'lat', 'lng', 'station', 'taste', 'env', 'service']
        s1 = ','.join(userful_columns)
        s2 = r"%s,"*(len(userful_columns)-1) + r"%s"
        sql_string = 'insert into ShopsStationGuanggou(%s) values (%s)' % (s1, s2)

        try:
            self.cursor.execute(sql_string, infoList)
        except:
            print('fail', infoList[0], infoList[1], infoList[5], '='*20)

    def ImgInfoStorage(self, shopid, infoList):
        sql_string = 'insert into ImgGuangZhou(shopId, img) values (%s, %s)'

        for i in infoList:
            try:
                self.cursor.execute(sql_string, [shopid, i])
            except:
                print('fail picture', i, '+'*20)
