import scrapy
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
import datetime as dt
from urllib.parse import urlencode
import json
import time

class DamaiMainSpider(scrapy.Spider):
    name = 'damaiMain'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(DamaiMainSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        url = self.start_urls[0]
        data = {'cty':'广州','order':2,'currPage':1}
        url = url + "?" + urlencode(data)

        yield scrapy.Request(url=url, headers=self.headers)

    def parse(self, response):
        damai_json = json.loads(response.text)
        damai_json = damai_json['pageData']
        crt_page = damai_json['currentPage']
        next_page = damai_json['nextPage']
        if 'resultData' in damai_json:
            for item in damai_json['resultData']:
                q_item = DamaiMainItem()
                q_item['projectid'] = item['projectid']
                q_item['nameNoHtml'] = item['nameNoHtml']
                q_item['showstatus'] = item['showstatus']
                q_item['actors'] = item['actors']
                q_item['categoryname'] = item['categoryname']
                q_item['subcategoryname'] = item['subcategoryname']
                q_item['description'] = item['description']
                q_item['subhead'] = item['subhead']
                q_item['venue'] = item['venue']
                q_item['venuecity'] = item['venuecity']
                duration = item['showtime']           #############

                q_item['showtime_start'] = None
                q_item['showtime_end'] = None
                if duration != None:
                    if u'有效期至' in duration:
                        q_item['showtime_end'] = duration.split(u'有效期至')[1].replace('.','-')
                    elif u'常年项目' in duration:
                        pass
                    else:
                        duration = duration.split('-')
                        if len(duration) == 1:
                            q_item['showtime_start'] = duration[0]
                            q_item['showtime_start'] = q_item['showtime_start'].replace('.','-')
                            q_item['showtime_end'] = q_item['showtime_start']
                        elif len(duration) == 2:
                            q_item['showtime_start'] = duration[0]
                            q_item['showtime_start'] = q_item['showtime_start'].replace('.','-')
                            q_item['showtime_end'] = duration[1]
                            q_item['showtime_end'] = q_item['showtime_end'].replace('.','-')
                            if len(q_item['showtime_end']) == 5:
                                q_item['showtime_end'] = '2017-'+ q_item['showtime_end']
                
                if 'favourable' not in item:
                    q_item['favourable'] = 'NULL'
                else:
                    favourable_list = item['favourable']
                    q_item['favourable'] = None
                    if favourable_list != None and len(favourable_list) > 0:
                        q_item['favourable'] = ''
                        for tmp in favourable_list:
                            q_item['favourable'] +=('+'+tmp)
                        q_item['favourable'] = q_item['favourable'][1:]        

                if 'favourites' not in item:
                    q_item['favourites'] = 'NULL'
                else:
                    q_item['favourites'] = item['favourites']
                if 'price_str' in item:
                    tmp = item['price_str']
                    if u'-' in tmp:
                        tmp_index = tmp.find(u'-')
                        q_item['price_low'] = float(tmp[:tmp_index])
                        q_item['price_high'] = float(tmp[tmp_index+1:])
                    else:
                        q_item['price_low'] = q_item['price_high'] = float(tmp)
                else:
                    q_item['price_low'] = q_item['price_high'] = 'NULL'
                q_item['update_date'] = time.strftime('%Y-%m-%d %H:%M:%S')
                yield q_item

            if crt_page != next_page:
                data = {'cty':'广州','order':2,'currPage':1}#order=2 时间排序
                data['currPage'] = crt_page
                url = "https://search.damai.cn/searchajax.html"
                url = url + "?" + urlencode(data)
                # data 这样传对吗？
                yield scrapy.Request(url=url, callback=self.parse)
