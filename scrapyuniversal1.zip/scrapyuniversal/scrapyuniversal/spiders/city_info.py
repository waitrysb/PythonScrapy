# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapyuniversal.utils import get_config
from scrapyuniversal.utils import _md5
from scrapyuniversal.utils import _get_md5_encrypted_string
from scrapyuniversal.items import *
from scrapyuniversal.urls import get_country_id
import datetime
import time
import json
import re

class CityInfoSpider(scrapy.Spider):
    name = 'city_info'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        self.url = 'http://www.mafengwo.cn/mdd/base/list/pagedata_citylist'
        self.encrypted_string = _get_md5_encrypted_string()
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        print("Start city_info Spider")
        super(CityInfoSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        country_list = get_country_id()
        for country_id in country_list:
            my_data = _md5({
                'mddid': country_id[0],
                'page': 1
            }, self.encrypted_string)
            data = 'mddid=' + str(country_id[0]) + '&page=' + str(1) + '&_ts=' + my_data['_ts'] + '&_sn=' + my_data['_sn']
            yield scrapy.Request(url=self.url, method='POST', body=data, headers=self.headers, callback=self.parse)

    def parse(self, response):
        country_id = str(response.request.body).split('=')[1].split('&')[0]
        data_json = json.loads(response.body.decode("utf-8"))
        text = Selector(text=data_json['list'])
        cities = text.xpath('.//li')
        for city in cities:
            names = city.xpath('.//div[@class="title"]//text()').extract()
            name = names[0].strip()
            en_name = names[1].strip()
            dest_id = city.css('a[data-type="目的地"]::attr(data-id)').extract_first()
            item = CityItem()
            item['id'] = dest_id
            item['city'] = "'" + name + "'"
            item['en_name'] = "'" + en_name + "'"
            item['country_id'] = country_id
            yield item
        next_page = Selector(text=data_json['page']).css('.pg-next::attr(data-page)').extract_first()
        time.sleep(3)
        #爬取下一页，如果爬取失败，再检查一下allowed_domains是否正确
        if next_page: 
            my_data = _md5({
                'mddid': country_id,
                'page': next_page
            }, self.encrypted_string)
            next_param = 'mddid=' + str(country_id) + '&page=' + str(next_page) + '&_ts=' + my_data['_ts'] + '&_sn=' + my_data['_sn']
            yield scrapy.Request(url=self.url, method='POST', body=next_param, headers=self.headers, callback=self.parse)




