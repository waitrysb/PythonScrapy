# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import *
from scrapyuniversal.items import *
import datetime as dt
import json
from scrapyuniversal.weibo import APIClient
import pymysql

class WeiboWinSpider(scrapy.Spider):
    name = 'weiboWin'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        self.userName = config.get('userName')
        self.passWord = config.get('passWord')
        self.user_max_id  = config.get('user_max_id')
        self.APP_KEY = config.get('APP_KEY')
        self.APP_SECRET = config.get('APP_SECRET')
        self.CALLBACK_URL = config.get('CALLBACK_URL')
        self.table = config.get('table')
        super(WeiboWinSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        url = self.start_urls[0]
        meta = {}
        for i in range(0, len(self.passWord)):
            meta['passWord'] = self.passWord[i]
            meta['userName'] = self.userName[i]
            meta['index'] = i
            print('-----------------------------------------------------------------------------'+ str(i))
            yield scrapy.Request(url=url, headers=self.headers, meta=meta,  dont_filter=True)
            break

    def parse(self, response):
        self.logger.debug(response.url)
        APP_KEY = self.APP_KEY
        APP_SECRET = self.APP_SECRET
        CALLBACK_URL = self.CALLBACK_URL
        client = APIClient(app_key=APP_KEY, app_secret=APP_SECRET, redirect_uri=CALLBACK_URL)
        code = response.url.split("=")[1]
        r = client.request_access_token(code)  
        access_token = r.access_token # 新浪返回的token，类似abc123xyz456  
        expires_in = r.expires_in  
        # 设置得到的access_token  
        client.set_access_token(access_token, expires_in) 
        index = response.meta['index']
        for x in range(1,30):
        #statuses = client.statuses__friends_timeline(page=x,count=100)['statuses']
            statuses = client.statuses__home_timeline(page=x,count=100,max_id=self.user_max_id[index])['statuses']
            length = len(statuses) 
            for i in range(0,length): 
                #'昵称：'+statuses[i]['user']['screen_name']  
                #print u'简介：'+statuses[i]['user']['description']  
                #print u'位置：'+statuses[i]['user']['location']
                w_item = WeiboWinItem()
                w_item['original_pic'] = ''
                w_item['bmiddle_pic'] = ''
                w_item['thumbnail_pic'] = ''
                #pic = ["","",""] 
                if(statuses[i].__contains__('original_pic')):
                    w_item['original_pic'] = statuses[i]['original_pic']
                if(statuses[i].__contains__('bmiddle_pic')):
                    w_item['bmiddle_pic'] = statuses[i]['bmiddle_pic']
                if(statuses[i].__contains__('thumbnail_pic')):
                    w_item['thumbnail_pic'] = statuses[i]['thumbnail_pic']
                w_item['comment_count'] = str(statuses[i]['comments_count'])
                w_item['repost_count'] = str(statuses[i]['reposts_count'])
                w_item['attitudes_count'] = str(statuses[i]['attitudes_count'])


                # filter
                # statuses[i]['text'] = statuses[i]['text'].decode('utf-8')
                if(u'发表了博文' in statuses[i]['text']):
                #print 'filter :',1,statuses[i]['text']
                    continue
                if(statuses[i]['text'].startswith(u'转发微博')):
                #print 'filter :',2,statuses[i]['text']
                    continue
                if(len(statuses[i]['text'])<= 3):
                #print 'filter :',3,statuses[i]['text']
                    continue
                if(statuses[i]['text'].startswith('[') and statuses[i]['text'].endswith(']') and len(statuses[i]['text'])<=2+3*6):
                #print 'filter :',4,statuses[i]['text']
                    continue
                w_item['table'] = self.table
                w_item['since_id'] = statuses[i]['id']
                w_item['weibo_content'] = pymysql.escape_string(statuses[i]['text'])
                w_item['weibo_author'] = statuses[i]['user']['name']
                w_item['fans_count'] = str(statuses[i]['user']['followers_count'])
                w_item['friends_count'] = str(statuses[i]['user']['friends_count'])
                w_item['gender'] = statuses[i]['user']['gender']
                w_item['verified_type'] = str(statuses[i]['user']['verified_type'])
                w_item['location'] = statuses[i]['user']['location']
                w_item['weibo_time'] = getTime(statuses[i]['created_at'])
                w_item['user_time'] = getTime(statuses[i]['user']['created_at'])

                yield w_item

               
                    # since_id = Field()
                    # weibo_content = Field()
                    # weibo_author = Field()
                    # comment_count = Field()
                    # repost_count = Field()
                    # attitudes_count = Field()
                    # fans_count = Field()
                    # friends_count = Field()
                    # gender = Field()
                    # verified_type
                    # original_pic = Field()
                    # bmiddle_pic = Field()
                    # thumbnail_pic = Field()
                    # location = Field()
                    # weibo_time = Field()
                    # user_time = Field()