# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapyuniversal.utils import get_config
from scrapyuniversal.utils import _md5
from scrapyuniversal.utils import _get_md5_encrypted_string
from scrapyuniversal.items import *
from scrapyuniversal.urls import get_city_id
import datetime
import time
import json
import re

class SceneInfoSpider(scrapy.Spider):
    name = 'scene_info'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        self.url = 'http://www.mafengwo.cn/ajax/router.php'
        self.encrypted_string = _get_md5_encrypted_string()
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(SceneInfoSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        city_list = get_city_id()
        for city_id in city_list:
            my_data = _md5({
                'sAct': 'KMdd_StructWebAjax|GetPoisByTag',
                'iMddid': city_id[0],
                'iTagId': 0,
                'iPage': 1
            }, self.encrypted_string)
            data = 'sAct=' + 'KMdd_StructWebAjax%7CGetPoisByTag' + '&iMddid=' + str(city_id[0]) + '&iTagId=' + str(0) + '&iPage=' + str(1) + '&_ts=' + my_data['_ts'] + '&_sn=' + my_data['_sn']
            yield scrapy.Request(url=self.url, method='POST', body=data, headers=self.headers, callback=self.parse)

    def parse(self, response):
        city_id = str(response.request.body).split('=')[2].split('&')[0]
        data_json = json.loads(response.body.decode("utf-8"))
        
        text = Selector(text=data_json['data']['list'])
        scenes = text.xpath('.//li')
        for scene in scenes:
            id = scene.css('a::attr(href)').extract_first().split('/')[2].split('.')[0]
            name = scene.css('a::attr(title)').extract_first()
            
            item = SceneItem()
            item['id'] = id
            if name:
                item['scene'] = "'" + name + "'"
            item['city_id'] = city_id
            yield item
            

        next_page = Selector(text=data_json['data']['page']).css('.pg-next::attr(data-page)').extract_first()
        time.sleep(3)
        #爬取下一页，如果爬取失败，再检查一下allowed_domains是否正确
        if next_page: 
            data = _md5({
                'sAct': 'KMdd_StructWebAjax|GetPoisByTag',
                'iMddid': city_id,
                'iTagId': 0,
                'iPage': next_page
            }, self.encrypted_string)
            next_param = 'sAct=' + 'KMdd_StructWebAjax%7CGetPoisByTag' + '&iMddid=' + str(city_id) + '&iTagId=' + str(0) + '&iPage=' + str(next_page) + '&_ts=' + data['_ts'] + '&_sn=' + data['_sn']
            yield scrapy.Request(url=self.url, method='POST', body=next_param, headers=self.headers, callback=self.parse)



