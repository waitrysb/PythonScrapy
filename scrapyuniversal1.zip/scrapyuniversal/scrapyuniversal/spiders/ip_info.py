# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import get_config
from scrapyuniversal.utils import judge_ip
from scrapyuniversal.items import *
import datetime
import json
import re
import time

class IPInfoSpider(scrapy.Spider):
    name = 'ip_info'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(IPInfoSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        url = self.start_urls[0]
        yield scrapy.Request(url=url, headers=self.headers)

    def parse(self, response):
        ip_list = response.xpath('//tr')
        for ip_info in ip_list[1:]:
            speed = ip_info.css('.bar::attr(title)').extract_first()
            if speed:
                speed = float(speed.split('秒')[0])
            texts = ip_info.css('td::text').extract()
            ip = texts[0]
            port = texts[1]
            proxy_type = ip_info.xpath('td[6]/text()').extract_first()
            if not judge_ip(ip, port):
                continue;
            item = IPItem()
            item['speed'] = str(speed)
            item['ip'] = "'" + ip + "'"
            item['port'] = port
            item['type'] = "'" + proxy_type + "'"
            yield item
        next_page = response.css('.next_page::attr(href)').extract_first()
        time.sleep(5)
        #爬取下一页，如果爬取失败，再检查一下allowed_domains是否正确
        if next_page is not None: 
            next_page = response.urljoin(next_page)
            print(next_page)
            yield scrapy.Request(next_page, headers=self.headers, callback=self.parse)

