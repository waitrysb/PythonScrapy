# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy import Field


class ScrapyuniversalItem(scrapy.Item):
	title = Field()
	url = Field()
	text = Field()
	datetime = Field()
	source = Field()
	website = Field()

class MojiItem(scrapy.Item):
	table = Field()
	city = Field()
	pred_time = Field()
	weather = Field()
	temp = Field()
	temp_feel = Field()
	wind_level = Field()
	wind_dir = Field()
	humidity = Field()

class BaiduMapItem(scrapy.Item):
	table = Field()
	uid = Field()
	address = Field()
	name = Field()
	station = Field()
	area = Field()
	city = Field()
	province = Field()
	lat = Field()
	lng = Field()
	telephone = Field()
	distance = Field()
	type = Field()
	tag1 = Field()
	tag2 = Field()
	price = Field()
	street_id = Field()
	navi_lat = Field()
	navi_lng = Field()
	detail_url = Field()
	shop_hours = Field()
	overall_rating = Field()
	taste_rating = Field()
	service_rating = Field()
	environment_rating = Field()
	facility_rating = Field()
	hygiene_rating = Field()
	technology_rating = Field()
	image_num = Field()
	groupon_num = Field()
	discount_num = Field()
	comment_num = Field()
	favorite_num = Field()
	checkin_num = Field()

class DamaiMainItem(scrapy.Item):
	projectid = Field()
	nameNoHtml = Field()
	showstatus = Field()
	actors = Field()
	categoryname = Field()
	subcategoryname = Field()
	description = Field()
	subhead = Field()
	favourable = Field()
	favourites = Field()
	price_low = Field()
	price_high = Field()
	venue = Field()
	venuecity = Field()
	showtime_start = Field()
	showtime_end = Field()
	update_date = Field()

class DamaiPageItem(scrapy.Item):
	projectid = Field()
	price_all = Field()
	show_times = Field()
	update_date = Field()

class DamaiAddrItem(scrapy.Item):
	proj_id = Field()
	station_name = Field()
	lat = Field()
	lng = Field()
	update_date = Field()

class QingtingItem(scrapy.Item):
	id = Field()
	category = Field()
	title = Field()
	cover = Field()
	description = Field()
	playcount = Field()
	score = Field()
	type = Field()
	category = Field()
	update_time = Field()
	page = Field()
	m4a_url= Field()
	m4a_num = Field()

class WeiboWinItem(scrapy.Item):
	since_id = Field()
	weibo_content = Field()
	weibo_author = Field()
	comment_count = Field()
	repost_count = Field()
	attitudes_count = Field()
	fans_count = Field()
	friends_count = Field()
	gender = Field()
	verified_type = Field()
	original_pic = Field()
	bmiddle_pic = Field()
	thumbnail_pic = Field()
	location = Field()
	weibo_time = Field()
	user_time = Field()
	table = Field()

class DazhongDItem(scrapy.Item):
	dish_id = Field()
	shop_id = Field()
	price = Field()
	rec_cnt = Field()
	dish_name = Field()
	picture_url = Field()
	update_date = Field()

class DianPingItem(scrapy.Item):
	test = Field()

class TrainNumItem(scrapy.Item):
	date = Field()
	train_num = Field()
	start_station = Field()
	end_station = Field()
	train_type = Field()
	train_no = Field()
	
class TrainStationItem(scrapy.Item):
	station_order = Field()
	train_num = Field()
	station_name = Field()
	arrive_time = Field()
	depart_time = Field()
	stay_interval = Field()

class CountryItem(scrapy.Item):
	id = Field()
	country = Field()
	en_name = Field()
	continent = Field()

class CityItem(scrapy.Item):
	id = Field()
	city = Field()
	en_name = Field()
	country_id = Field()

class IPItem(scrapy.Item):
	id = Field()
	ip = Field()
	port = Field()
	type = Field()
	speed = Field()

class SceneItem(scrapy.Item):
	id = Field()
	city_id = Field()
	scene = Field()
	en_name = Field()
	description = Field()
	telephone = Field()
	website = Field()
	time_recommend = Field()
	traffic = Field()
	ticket = Field()
	location = Field()
	bussiness_hours = Field()
	latitude = Field()
	longitude = Field()

class ToutiaoNewsItem(scrapy.Item):
	item_id = Field()
	behot_time = Field()
	source = Field()
	source_url = Field()
	chinese_tag = Field()
	tag = Field()
	tag_url = Field()
	title = Field()
	abstract = Field()
	category = Field()
