
from os.path import realpath, dirname
import json
import pymysql
import random
import request
import requests
import re
import time
import hashlib
import threading
from bs4 import BeautifulSoup

def get_config(name): 
    """获取配置文件
    """
    path = dirname(realpath(__file__)) + '/configs/' + name + '.json'
    print(path)
    with open(path, 'r', encoding='utf-8') as f:
        return json.loads(f.read())

def haversine(lon1, lat1, lon2, lat2): # 经度1，纬度1，经度2，纬度2 （十进制度数）  
    """ 
    Calculate the great circle distance between two points  
    on the earth (specified in decimal degrees) 
    """  
    import math
    # 将十进制度数转化为弧度  
    lon1, lat1, lon2, lat2 = map(math.radians, [lon1, lat1, lon2, lat2])  
    # haversine公式  
    dlon = lon2 - lon1   
    dlat = lat2 - lat1   
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2  
    c = 2 * math.asin(math.sqrt(a))   
    r = 6371 # 地球平均半径，单位为公里  
    return c * r * 1000

def fix_format(content):
    if content == None:
        return 'None'
    else:
        return pymysql.escape_string(str(content.encode('utf-8')))

def getTime(origin): ##weiboWin
    month = {"Jan":"01","Feb":"02","Mar":"03","Apr":"04","May":"05","Jun":"06","Jul":"07","Aug":"08","Sep":"09","Oct":"10","Nov":"11","Dec":"12"}
    time = origin.split(" ")
    result = time[5]+'-'+month[time[1]]+'-'+time[2]+" "+time[3]
    return result

def getHeader(headers, agents):
    #print(headers)
    headers['Cookie'] = '_lxsdk_cuid=16290e55669c8-03b2f53a9bd84c-3b7c015b-f8e20-16290e5566ac8; _lxsdk=16290e55669c8-03b2f53a9bd84c-3b7c015b-f8e20-16290e5566ac8; _hc.v=1641fc92-0498-b383-9578-42be19b641cd.1522849372; s_ViewType=10; ua=dpuser_0216512946; ctu=f401152de26c5a5d4a2ac45e2b28e9656a41891a3537d1f951aedd93d7ea1746; _lxsdk_s=%7C%7C{}'.format(random.randint(0,100))
    headers['User-Agent'] =agents[random.randint(0, len(agents)-1)]
    #print (headers)
    return headers

def getProxies():
    sql = "SELECT * FROM proxypool"
    con = {
        "MYSQL_HOST" : "127.0.0.1",
        "MYSQL_DATABASE" : "IPProxyPool",
        "MYSQL_PORT" : 3306,
        "MYSQL_USER" : "root",
        "MYSQL_PASSWORD" : "123456"
    }
    db = pymysql.connect(con["MYSQL_HOST"], con['MYSQL_USER'], con['MYSQL_PASSWORD'], con['MYSQL_DATABASE'], charset='utf8', port=con['MYSQL_PORT'])
    cursor = db.cursor()
    cursor.execute(sql)
    ip_list = cursor.fetchall()
    db.close()
    ip_addr = []
    for ip_info in ip_list:
        #if judge_ip(ip_info[1], ip_info[2]):
            addr = 'http://' + ip_info[1] + ":" + str(ip_info[2])
            ip_addr.append(addr)
    return ip_addr

def judge_ip(ip, port):
    # 判断ip是否可用
    http_url = 'http://www.baidu.com'
    proxy_url = 'http://{0}:{1}'.format(ip, port)
    try:
        proxy_dict = {
            'http': proxy_url
        }
        response = requests.get(http_url, proxies=proxy_dict)
    except:
        print("该ip：{0}不可用".format(ip))
        #delete_ip(ip)
        return False
    else:
        code = response.status_code
        if code >= 200 and code < 300:
            #print("ip:{0}有效".format(ip))
            return True
        else:
            print("该ip：{0}不可用".format(ip))
            #delete_ip(ip)
            return False

def _md5(data, encrypted_string):
        '''
        获取请求参数中的加密参数，_ts 和 _sn
        '''
        _ts = int(round(time.time() * 1000))
        data['_ts'] = _ts
        # 数据对象排序并字符串化
        orderd_data = _stringify(data)
        # md5 加密
        m = hashlib.md5()
        m.update((json.dumps(orderd_data, separators=(',', ':')) +
                  encrypted_string).encode('utf8'))
        _sn = m.hexdigest()
        # _sn 是加密后字符串的一部分
        orderd_data['_sn'] = _sn[2:12]
        return orderd_data

def _stringify(data):
        """
        将 dict 的每一项都变成字符串
        """
        data = sorted(data.items(), key=lambda d: d[0])
        new_dict = {}
        for item in data:
            if type(item[1]) == dict:
                # 如果是字典类型，就递归处理
                new_dict[item[0]] = json.dumps(
                    _stringify(item[1]), separators=(',', ':'))
            else:
                if type(item[1]) == list:
                    # 如果是列表类型，就把每一项都变成字符串
                    new_list = []
                    for i in item[1]:
                        new_list.append(_stringify(i))
                    new_dict[item[0]] = new_list
                else:
                    if item[1] is None:
                        new_dict[item[0]] = ''
                    else:
                        new_dict[item[0]] = str(item[1])
        return new_dict

def _get_md5_encrypted_string():
        '''
        获取 MD5 加密 _sn 时使用的加密字符串
        每个实例只调用一次
        '''
        # 以北京景点为例，首先获取加密 js 文件的地址
        url = 'http://www.mafengwo.cn/jd/10065/gonglve.html'
        REQ = requests.session()
        HEADERS = {
            'Referer': 'http://www.mafengwo.cn/',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'
        }
        REQ.headers.update(HEADERS)
        r = REQ.get(url)

        if r.status_code == 403:
            exit('访问被拒绝，请检查是否为IP地址被禁')
        param = re.findall(
            r'src="http://js.mafengwo.net/js/hotel/sign/index.js(.*?)"', r.text)
        param = param[0]
        # 拼接 index.js 的文件地址
        url_indexjs = 'http://js.mafengwo.net/js/hotel/sign/index.js' + param
        # 获取 index.js
        r = REQ.get(url_indexjs)
        if r.status_code == 403:
            exit('访问被拒绝')
        response_text = r.text
        # 查找加密字符串
        result = re.findall(r'var __Ox2133f=\[(.*?)\];', response_text)[0]
        byteslike_encrypted_string = result.split(',')[46].replace('"', '')
        # 解码
        strTobytes = []
        for item in byteslike_encrypted_string.split('\\x'):
            if item != '':
                num = int(item, 16)
                strTobytes.append(num)
        # 转换字节为字符串
        encrypted_string = bytes(strTobytes).decode('utf8')
        return encrypted_string


def cleantxt(raw):
    fil = re.compile(u'[^0-9a-zA-Z\u4e00-\u9fa5.，,。？“”]+', re.UNICODE)
    return fil.sub(' ', raw) 

def getCookie(url, name):
    from selenium import webdriver
    driver=webdriver.Chrome()
    driver.get(url)
    cookies = driver.get_cookies()
    driver.quit()
    for cookie in cookies:
        if cookie['name'] == name:
            return cookie['value']
    return ""

