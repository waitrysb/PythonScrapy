import time
import os
while True:
  os.system("python run.py moji")
  time.sleep(86400/6) #每隔一天运行一次 24*60*60=86400s或者，使用标准库的sched模块