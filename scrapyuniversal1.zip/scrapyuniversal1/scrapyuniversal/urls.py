import time
import pymysql
from scrapyuniversal.utils import get_config

def china(start, end):
	for page in range(start, end+1):
		yield 'http://tech.china.com/articles/index_' + str(page) + '.html'

def damaiPage():

	crt_date = time.strftime('%Y-%m-%d')
	query_sql = "SELECT projectid FROM Activaty_on_Damai WHERE showtime_end>='%s' or showtime_end is null"%(crt_date) 
	db = connect()
	cursor = db.cursor()
	cursor.execute(query_sql)
	results = cursor.fetchall()
	for item in results:
		yield 'https://piao.damai.cn/ajax/getInfo.html?projectId=%s'%(item[0])
	db.close()

def connect():
	con = {
		"MYSQL_HOST" : "10.109.247.63",
		"MYSQL_DATABASE" : "mt_dp",
		"MYSQL_PORT" : 3306,
		"MYSQL_USER" : "root",
		"MYSQL_PASSWORD" : "hadoop"
	}
	db = pymysql.connect(con["MYSQL_HOST"], con['MYSQL_USER'], con['MYSQL_PASSWORD'], con['MYSQL_DATABASE'], charset='utf8', port=con['MYSQL_PORT'])
	return db
	
def damaiAddr():
	crt_date = time.strftime('%Y-%m-%d')
	db = connect()
	query_sql = "SELECT projectid,venue FROM Activaty_on_Damai where lng is NULL and venue is not null and  showtime_end>='%s'"%(crt_date)
	cursor = db.cursor()
	cursor.execute(query_sql)
	results = cursor.fetchall()
	for item in results:
		yield "https://piao.damai.cn/%d.html"%(item[0])
	db.close()

def gene_url():
	query_shop_id_sql = "SELECT shop_id FROM Shops_of_Station_GZ  WHERE platform='点评' AND INSTR('餐饮', tag)"
	db = connect()
	cursor = db.cursor()
	cursor.execute(query_shop_id_sql)
	shop_id_list = cursor.fetchall()
	for crt_shop_index, crt_shop_id in enumerate(shop_id_list):
		crt_url = 'http://www.dianping.com/shop/{}/dishlist/p{}'.format(crt_shop_id[0], 1)
		if crt_shop_index==2:
			break
		yield crt_url
	db.close()

def get_train_num():
	sql = "SELECT DISTINCT train_num FROM train_num_info"
	config = get_config('train_num')
	db = pymysql.connect(config.get("settings").get("MYSQL_HOST"), config.get("settings").get('MYSQL_USER'), config.get("settings").get('MYSQL_PASSWORD'), config.get("settings").get('MYSQL_DATABASE'), charset='utf8', port=config.get("settings").get('MYSQL_PORT'))
	cursor = db.cursor()
	cursor.execute(sql)
	train_num_list = cursor.fetchall()
	db.close()
	return train_num_list

def get_country_id():
	sql = "SELECT DISTINCT id FROM country_info"
	config = get_config('country_info')
	db = pymysql.connect(config.get("settings").get("MYSQL_HOST"), config.get("settings").get('MYSQL_USER'), config.get("settings").get('MYSQL_PASSWORD'), config.get("settings").get('MYSQL_DATABASE'), charset='utf8', port=config.get("settings").get('MYSQL_PORT'))
	cursor = db.cursor()
	cursor.execute(sql)
	country_list = cursor.fetchall()
	db.close()
	return country_list

def get_city_id():
	sql = "SELECT DISTINCT id FROM city_info"
	config = get_config('city_info')
	db = pymysql.connect(config.get("settings").get("MYSQL_HOST"), config.get("settings").get('MYSQL_USER'), config.get("settings").get('MYSQL_PASSWORD'), config.get("settings").get('MYSQL_DATABASE'), charset='utf8', port=config.get("settings").get('MYSQL_PORT'))
	cursor = db.cursor()
	cursor.execute(sql)
	city_list = cursor.fetchall()
	db.close()
	return city_list

def get_scene_id():
	sql = "SELECT DISTINCT id FROM scene_info WHERE latitude is null"
	config = get_config('scene_info')
	db = pymysql.connect(config.get("settings").get("MYSQL_HOST"), config.get("settings").get('MYSQL_USER'), config.get("settings").get('MYSQL_PASSWORD'), config.get("settings").get('MYSQL_DATABASE'), charset='utf8', port=config.get("settings").get('MYSQL_PORT'))
	cursor = db.cursor()
	cursor.execute(sql)
	city_list = cursor.fetchall()
	db.close()
	return city_list

def get_as_cp():  # 该函数主要是为了获取as和cp参数，程序参考今日头条中的加密js文件：home_4abea46.js
    zz = {}
    now = round(time.time())
    e = hex(int(now)).upper()[2:] #hex()转换一个整数对象为16进制的字符串表示
    import hashlib
    a = hashlib.md5()  #hashlib.md5().hexdigest()创建hash对象并返回16进制结果
    a.update(str(int(now)).encode('utf-8'))
    i = a.hexdigest().upper()
    if len(e)!=8:
        zz = {'as':'479BB4B7254C150',
        'cp':'7E0AC8874BB0985'}
        return zz
    n = i[:5]
    a = i[-5:]
    r = ''
    s = ''
    for i in range(5):
        s= s+n[i]+e[i]
    for j in range(5):
        r = r+e[j+3]+a[j]
    zz ={
    'as':'A1'+s+e[-3:],
    'cp':e[0:3]+r+'E1'
    }
    return zz

def get_news_url(category, max_behot_time):
	ascp = get_as_cp()
	max_behot_time = str(max_behot_time)
	return 'https://www.toutiao.com/api/pc/feed/?category=' + category + '&utm_source=toutiao&widen=1&max_behot_time='+max_behot_time+'&max_behot_time_tmp='+max_behot_time+'&tadrequire=true&as='+ascp['as']+'&cp='+ascp['cp']




