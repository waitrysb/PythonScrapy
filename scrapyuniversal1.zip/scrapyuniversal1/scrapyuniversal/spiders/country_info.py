# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
import datetime
import json
import re

class CountryInfoSpider(scrapy.Spider):
    name = 'country_info'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(CountryInfoSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        url = self.start_urls[0]
        yield scrapy.Request(url=url, headers=self.headers)

    def parse(self, response):
        continents = response.xpath('//div[@class="row-list"]/div[@class="bd"]/dl')
        for continent in continents:
            continent_name = continent.xpath('./dt/text()').extract_first()
            print(continent_name)
            countries = continent.xpath('./dd//a')
            for country in countries:
                href = country.xpath('./@href').extract_first()
                item = CountryItem()
                id = re.findall("\d+", href)[0]
                name = country.xpath('./text()').extract_first().strip()
                en_name = str(country.xpath('./span/text()').extract_first()).strip()
                item['id'] = id
                item['country'] = "'" + name + "'"
                item['en_name'] = "'" + en_name + "'"
                item['continent'] = "'" + continent_name + "'"
                yield item
