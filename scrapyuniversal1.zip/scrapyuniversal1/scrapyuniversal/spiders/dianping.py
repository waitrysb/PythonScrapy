# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import *
from scrapyuniversal.items import *
import datetime as dt
import json
import pymysql

class WeiboWinSpider(scrapy.Spider):
    name = 'dianping'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        #self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(WeiboWinSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        url = self.start_urls[0]
        
        #yield scrapy.Request(url=url, headers=self.headers, meta=meta,  dont_filter=True)
        yield scrapy.Request(url=url,  dont_filter=True)
        

    def parse(self, response):
        self.logger.debug(response.url)
        item = DianPingItem()
        item['test'] = "test"
        #yield item
        print('-----------------------')
       