# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import *
from scrapyuniversal.urls import *
from scrapyuniversal import urls
from scrapyuniversal.items import *
import datetime as dt
import time
from bs4 import BeautifulSoup
import re

class DazhongDSpider(scrapy.Spider):
    name = 'dazhongD'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        self.agents = config.get('settings').get('agents')
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(DazhongDSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        for url in list(self.start_urls):
            headers = getHeader(self.headers, self.agents)
            print (headers)
            yield scrapy.Request(url=url, headers=headers)


    def parse(self, response):
        soup=BeautifulSoup(response.text,'lxml',from_encoding='utf-8') 
        dish_list = soup.find_all('div', class_='list-desc')
        if len(dish_list)==0 or len(dish_list[0].find_all('a')) <= 0:
            print("---------------------------------------------------------"+ str(response.status))
            return
        else:
            # TODO: shop_id 可以从 url 中解析出来，crt_url = 'http://www.dianping.com/shop/{}/dishlist/p{}'.format(crt_shop_id, 1)
            p = re.compile(r'shop/(.*)/dishlist')
            shop_id = p.search(response.url).group(1)
            print('---------------------------'+shop_id)

            update_date = time.strftime('%Y-%m-%d')
            for dish in dish_list[0].find_all('a', class_='shop-food-item'):
                re_dish_id = re.compile('/dish.*?"')
                dish_id = re_dish_id.search(str(dish))
                if dish_id:
                    dish_id = dish_id.group()
                    dish_id = str(int(dish_id[dish_id.find('dish')+4:-1]))
                else:
                    print("can't find dish id",  str(dish))
                    continue
                
                img = dish.find('img')
                picture_url = img.attrs['src']

                dish_name = dish.find('div', class_='shop-food-name')
                if dish_name!=None:
                    dish_name = dish_name.text
                    print("---------------------------------"+ dish_name)
                rec_cnt = dish.find('div', class_='recommend-count')
                if rec_cnt!=None:
                    rec_cnt = rec_cnt.text
                    if rec_cnt.find(u'人') >= 0:
                        rec_cnt = str(int(rec_cnt[:rec_cnt.find(u'人')]))
                    else:
                        rec_cnt = 'NULL'
                        
                price = dish.find('div', class_='shop-food-money')
                if price!=None:
                    price = price.text
                    if price.find(u'￥') >= 0:
                        price = str(int(price[price.find(u'￥')+1:]))
                    else:
                        price = 'NULL'
                
                q_item = DazhongDItem()
                q_item['dish_id'] = dish_id
                q_item['shop_id'] = shop_id
                q_item['price'] = price
                q_item['rec_cnt'] = rec_cnt
                q_item['dish_name'] = dish_name
                q_item['picture_url'] = picture_url
                q_item['update_date'] = update_date
                yield q_item

            # TODO: crt_page 可以从 url 中解析出来，crt_url = 'http://www.dianping.com/shop/{}/dishlist/p{}'.format(crt_shop_id, 1)
            
            p = re.compile(r'dishlist/p(.*)')
            crt_page  = int(p.search(response.url).group(1))

            yield scrapy.Request(url='http://www.dianping.com/shop/{}/dishlist/p{}'.format(shop_id, crt_page+1), callback=self.parse)

#{'Cookie': '_lxsdk_cuid=16290e55669c8-03b2f53a9bd84c-3b7c015b-f8e20-16290e5566ac8; _lxsdk=16290e55669c8-03b2f53a9bd84c-3b7c015b-f8e20-16290e5566ac8; _hc.v=1641fc92-0498-b383-9578-42be19b641cd.1522849372; s_ViewType=10; ua=dpuser_0216512946; ctu=f401152de26c5a5d4a2ac45e2b28e9656a41891a3537d1f951aedd93d7ea1746; _lxsdk_s=%7C%7C88', 'Host': 'www.dianping.com', 'Connection': 'keep-alive', 'Accept-Encoding': 'gzip, deflate', 'Referer': 'http://www.baidu.com/', 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'Cache-Control': 'max-age=0', 'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36'}