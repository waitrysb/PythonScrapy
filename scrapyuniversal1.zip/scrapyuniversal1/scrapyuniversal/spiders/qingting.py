# -*- coding: utf-8 -*-
import scrapy
from bs4 import BeautifulSoup
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
import datetime as dt
from urllib.parse import urlencode
import json
import time

class QingtingSpider(scrapy.Spider):
    name = 'qingting'
    allowed_domains = []
    start_urls = ['https://www.qingting.fm/categories']
    headers = {
        'Origin':'http://www.qingting.fm',
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
    }

    def __init__(self, name, *args, **kwargs):
        super(QingtingSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.headers)

    def parse(self, response):
        tmp_dict = {}
        soup = BeautifulSoup(response.text, 'lxml')
        a = soup.find_all(class_="_3fnw")

        for item in a:
            tmp_dict[item.get_text()] = item['href'][:-2]
#http://www.qingting.fm/categories/3251/0/2
        for i in tmp_dict.items():
            url = 'http://www.qingting.fm/' + str(i[1]) + '/1'
            
            yield scrapy.Request(url=url,meta={"category":i}, callback=self.parse1)

    def parse1(self, response):
        soup = BeautifulSoup(response.text, 'lxml')
        a = soup.find_all(class_="_2k3q")[-1]
        num = int(a['aria-label'][a['aria-label'].rfind(' ') + 1:])

        for i in range(1, num+1):
            global_url = response.meta['category'][1]
            data = {'category':global_url[global_url.find('ies') + 4:global_url.rfind('/')], 'attrs':0, 'curpage':i}
            url = 'http://i.qingting.fm/capi/neo-channel-filter' + '?' + urlencode(data)
            yield scrapy.Request(url=url, callback=self.parse2, meta={"category":response.meta['category']})

    def parse2(self, response):
        data = json.loads(response.text)['data']['channels']

        for i, item in enumerate(data):
            q_item = QingtingItem()
            q_item["category"] = response.meta['category'][0]
            try:
                q_item['title'] = item['title']
                q_item['cover'] = item['cover']
                q_item['description'] = item['description']
                q_item['id'] = str(item['id'])
                q_item['playcount'] = item['playcount']
                q_item['score'] = str(item['score'])
                q_item['type'] = item['type']
                q_item['update_time'] = item['update_time']
            except:
                q_item['title'] = item['title']
                q_item['cover'] = item['cover']
                q_item['description'] = item['description']
                q_item['id'] = str(item['id'])
                q_item['playcount'] = item['playcount']
                q_item['score'] = '0'
                q_item['type'] = ''
                q_item['update_time'] = item['update_time']
        #time.sleep(1)

        url = 'http://www.qingting.fm/channels/' + q_item['id'] + '/1'
        yield scrapy.Request(url=url, callback=self.parse3, meta={"item":q_item})

    def parse3(self, response):
        soup = BeautifulSoup(response.text, 'lxml')

        try:
            a = soup.find_all(class_="_2k3q")[-1]
            num = int(a['aria-label'][a['aria-label'].rfind(' ') + 1:])
        except:
            num = 1

        temp = response.meta['item']
        temp['page'] = num

        for i in range(1, num+1):
            yield scrapy.Request(url='http://i.qingting.fm/wapi/channels/' + temp['id'] +
            '/programs/page/' + str(i) + '/pagesize/10', callback=self.parse4, meta={"item":temp})

    def parse4(self, response):
        data = json.loads(response.text)['data']
        m4a_list = []
        baseurl = 'http://od.qingting.fm/'

        for item in data:
            try:
                m4a_list.append(baseurl + item['file_path'])
            except:
                continue
                
        temp = response.meta['item']
        temp['m4a_num'] = len(m4a_list)
        temp['m4a_url'] = ('+').join(m4a_list)
        yield temp






