# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
from scrapyuniversal.utils import _md5
from scrapyuniversal.utils import _get_md5_encrypted_string
from scrapyuniversal.urls import get_scene_id
from scrapyuniversal.utils import cleantxt
import datetime
import time
import json
import re

class SceneDetailSpider(scrapy.Spider):
    name = 'scene_detail'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        self.encrypted_string = _get_md5_encrypted_string()
        self.url = 'http://www.mafengwo.cn/poi/'
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(SceneDetailSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        scene_list = get_scene_id()
        for scene_id in scene_list:
            url = self.url + str(scene_id[0]) + '.html'
            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        scene_id = str(response.request.url).split('/')[4].split('.')[0]
        data = Selector(text=response.body)
        en_name = data.xpath('//div[@class="row row-top"]//div[@class="en"]/text()').extract_first()
        detail = data.xpath('.//div[@class="mod mod-detail"]')
        location = data.xpath('.//div[@class="mod mod-location"]//p/text()').extract_first()
        descriptions = detail.xpath('./div[@class="summary"]/text()').extract()
        description = ''
        for descript in descriptions:
            description += cleantxt(descript).strip() + "\n"
        telephone = detail.xpath('.//li[@class="tel"]/div[@class="content"]/text()').extract_first()
        site = detail.xpath('.//li[@class="item-site"]/div[@class="content"]/a/text()').extract_first()
        recommend_time = detail.xpath('.//li[@class="item-time"]/div[@class="content"]/text()').extract_first()
        dl = detail.xpath('.//dl')
        traffic = ""
        ticket = ""
        open_time = ""
        for xx in dl:
            part = xx.xpath('.//dt/text()').extract_first()
            if part == "交通":
                routes = xx.xpath('.//dd//text()').extract()
                for route in routes:
                    traffic += route.strip() + "\n"
            elif part == "门票":
                money_list = xx.xpath('.//dd//text()').extract()
                for money in money_list:
                    ticket += money.strip() + "\n"
            elif part == "开放时间":
                time_list = xx.xpath('.//dd//text()').extract()
                for interval in time_list:
                    open_time += interval.strip() + "\n"
        item = SceneItem()
        item['id'] = scene_id
        if en_name:
            item['en_name'] = "'" + en_name + "'"
        if description != "":
            item['description'] = "'" + description + "'"
        if telephone:
            item['telephone'] = "'" + telephone + "'"
        if site:
            item['website'] = "'" + site + "'"
        if recommend_time:
            item['time_recommend'] = "'" + recommend_time + "'"
        if traffic != "":
            item['traffic'] = "'" + traffic + "'"
        if ticket != "":
            item['ticket'] = "'" + ticket + "'"
        if open_time != "":
            item['bussiness_hours'] = "'" + open_time + "'"
        if location:
            item['location'] = "'" + location + "'"
        yield item

        #发出获取经纬度请求
        my_data = _md5({
            "params": '{"poi_id":"' + scene_id + '"}',
        }, self.encrypted_string)
        data = 'params=' + str(my_data['params']) + '&_ts=' + my_data['_ts'] + '&_sn=' + my_data['_sn'] + '&_=' + my_data['_ts']
        url = 'http://pagelet.mafengwo.cn/poi/pagelet/poiLocationApi?' + data
        headers = {
            "Accept":"*/*",
            "Accept-Language":"zh-CN,zh;q=0.8",
            "Connection":"keep-alive",
            "DNT":"1",
            "Host":"pagelet.mafengwo.cn",
            "Referer":"http://www.mafengwo.cn",
            "X-Requested-With":"XMLHttpRequest"
        }
        yield scrapy.Request(url=url, headers=headers, callback=self.parseLocation)

    def parseLocation(self, response):
        data = json.loads(response.text)
        #print(data)
        try:
            item = SceneItem()
            item['id'] = data['data']['controller_data']['poi']['id']
            item['latitude'] = data['data']['controller_data']['poi']['lat']
            item['longitude'] = data['data']['controller_data']['poi']['lng']
            yield item
        except:
            yield scrapy.Request(url=response.request.url, headers=response.request.headers, callback=self.parseLocation)





