import scrapy
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
import datetime as dt
from urllib.parse import urlencode
import json
import time
from scrapyuniversal import urls
import re

class DamaiPageSpider(scrapy.Spider):
    name = 'damaiPage'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(DamaiPageSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        p = re.compile(r'projectId=(.*)')
        for i in self.start_urls:
            id = p.search(i).group(1)
            yield scrapy.Request(url=i, headers=self.headers, meta={"id":id})

    def parse(self, response):
        poj_detail_json = json.loads(response.text)
        item = DamaiPageItem()
        if poj_detail_json['Status'] == 200:
            poj_detail_json = poj_detail_json['Data']
            
            performs = poj_detail_json['performs']
            item['projectid'] = response.meta['id']
            show_times = set()
            for time_info in performs:
                show_times.add(time_info['ShowDate']+u' '+time_info['ShowTime'])
            show_times = ','.join(str(s) for s in show_times)
            item['show_times'] = 'null' if len(show_times) == 0 else show_times ##########################
            
            prices = poj_detail_json['prices']
            price_all = ','.join(str(price_info['SellPrice']) for price_info in prices) if prices!=None else None
            item['price_all'] = 'null' if price_all == None or len(price_all) == 0 else price_all
            item['update_date'] = time.strftime('%Y-%m-%d %H:%M:%S')
            yield item