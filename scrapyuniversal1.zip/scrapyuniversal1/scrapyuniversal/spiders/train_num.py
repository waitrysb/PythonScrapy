# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
import datetime
import json
import re

class TrainNumSpider(scrapy.Spider):
    name = 'train_num'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(TrainNumSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        url = self.start_urls[0]
        yield scrapy.Request(url=url, headers=self.headers)

    def parse(self, response):
        text = response.text
        dts = re.findall('"([0-9]{4}-[0-9]{0,2}-[0-9]{0,2})":\{', text)  # 2 解析出所有的日期（key）
        train_list = re.findall(r'=(.*)', text)[0]  # 3 解析出数据 r表示是原生字符串，一定是正则表达式，告诉编译器不用转义
        train_json = json.loads(train_list)  # 4 将数据载入字典，自动解析json
        from_day = datetime.datetime.now()
        delta = datetime.timedelta(days = self.config.get("days"))
        to_day = from_day + delta
        
        for dt in dts:
            temp_day = datetime.datetime.strptime(dt, '%Y-%m-%d')
            if (temp_day - from_day).days < 0 or (to_day - temp_day).days < 0:
                continue
            tjson_dt = train_json.get(dt)  # 所有日期（第一级日期为key）
            keys = tjson_dt.keys()  # 所有的车次类型，C,D,G,K,O,T,Z
            for key in keys:
                    dicts = tjson_dt.get(key)  # 取出对应类型的车次数据
                    for dic in dicts:
                        station_train_code = dic.get('station_train_code')
                        item = TrainNumItem()
                        item['date'] = "'" + dt + "'"
                        item['train_num'] = "'" + re.findall(r'^(.*)\(', station_train_code)[0] + "'"
                        item['start_station'] = "'" + re.findall(r'\((.*)-', station_train_code)[0] + "'"
                        item['end_station'] = "'" + re.findall(r'-(.*)\)', station_train_code)[0] + "'"
                        item['train_type'] = "'" + key + "'"
                        item['train_no'] = "'" + dic.get('train_no') + "'"
                        yield item
