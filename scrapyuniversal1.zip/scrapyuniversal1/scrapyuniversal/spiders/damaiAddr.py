import scrapy
from scrapyuniversal.utils import *
from scrapyuniversal.items import *
import datetime as dt
import json
import time
from scrapyuniversal import urls
import re

class DamaiAddSpider(scrapy.Spider):
    name = 'damaiAddr'

    def __init__(self, name, *args, **kwargs):
        self.logger.info(name)
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(DamaiAddSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        self.logger.info('Parse function called on %s', self.start_urls)
        for i in self.start_urls:
            self.logger.info(i+"-----------------------")
            yield scrapy.Request(url=i, headers=self.headers)

    def parse(self, response):
        print(1)
        item = DamaiAddrItem()
        db = urls.connect()
        cursor = db.cursor()
        station_loc_sql = 'SELECT station_name,lat,lng FROM Station_GZ'
        cursor.execute(station_loc_sql)
        stations = cursor.fetchall()
        db.close()
        addr_pattern = re.compile(r'CenterLngLat=[0-9.,]*') 
        match = addr_pattern.search(req.text) 
        if match:
            addr = match.group()
            lng = float(addr[addr.find('=')+1:addr.find(',')])
            lat = float(addr[addr.find(',')+1:])
            min_dist = 1001 #保证在1km内
            nearst_station = ""
            for station in stations:
                dist=haversine(lng,lat,station[2],station[1]) # lon,lat
                if dist < min_dist:
                    min_dist = dist
                    nearst_station = station[0]
            item['proj_id'] = response.url[response.url.rfind('/')+1:response.url.rfind('.')]
            item['station_name'] = nearst_station + "+" + str(min_dist) if min_dist < 1001 and len(nearst_station)>0 else 'NULL'
            item['lng'] = lng
            item['lat'] = lat
            yield item