# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector
from scrapyuniversal.utils import get_config
from scrapyuniversal.utils import getCookie
from scrapyuniversal.items import *
from scrapyuniversal.urls import get_news_url
import datetime
import time
import json
import re

class ToutiaoNewsSpider(scrapy.Spider):
    name = 'toutiao_news'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        self.categories = ['news_entertainment', 'news_game', 'news_sports', 'news_finance', 'news_military', 
    'news_fashion', 'news_travel', 'news_food', 'news_baby', 'news_culture', 'news_edu', 'news_tech', 'news_world', 
    'news_history', 'news_discovery', 'news_regimen', 'news_cars', 'news_house', 'news_astrology', 'news_health', 'news_home', 
    'news_society']
        #self.index = 0
        self.url = 'http://www.toutiao.com'
        self.count = 0
        self.last_count = 0
        self.app_id = 2297
        #self.headers['cookie'] = "tt_webid=" + getCookie("https://www.toutiao.com/", 'tt_webid')
        #self.getcookie_headers = {'Content-Type':'application/json'}
        #self.body = json.dumps({"app_id":2297,"url":"https://www.toutiao.com/","user_agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36","referer":"https://www.toutiao.com/","user_unique_id":""})
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(ToutiaoNewsSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        #news_url = get_news_url(self.categories[self.index], 0)
        for category in self.categories:
            yield scrapy.Request(url=get_news_url(category, 0), headers=self.headers, callback=self.parse)

    def parse(self, response):
        category = response.url.split('category=')[1].split('&')[0]
        if response.status == 200:
            text = json.loads(response.body)
            if ('message' in text.keys()) and (text['message'] == 'success'):
                data = text['data']
                for news in data:
                    keys = news.keys()
                    if ('article_genre' in keys) and (news['article_genre'] == 'article'):
                        item = ToutiaoNewsItem()
                        if 'item_id' in keys:
                            item['item_id'] = news['item_id']
                        if 'behot_time' in keys:
                            item['behot_time'] = str(news['behot_time'])
                        if 'source' in keys:
                            item['source'] = news['source']
                        if 'source_url' in keys:
                            item['source_url'] = news['source_url']
                        if 'chinese_tag' in keys:
                            item['chinese_tag'] = news['chinese_tag']
                        if 'tag' in keys:
                            item['tag'] = news['tag']
                        if 'tag_url' in keys:
                            item['tag_url'] = news['tag_url']
                        if 'title' in keys:
                            item['title'] = news['title']
                        if 'abstract' in keys:
                            item['abstract'] = news['abstract']
                        item['category'] = category
                        yield item
                        self.count += 1
                if (self.count - self.last_count) >= 200:
                    print(self.count)
                    #time.sleep(1)
                    self.last_count = self.count
                    #self.headers['cookie'] = getCookie("https://www.toutiao.com/", 'tt_webid')
                    #yield scrapy.Request(url='https://mcs.snssdk.com/v1/user/webid', method='POST', body=self.body, headers=self.getcookie_headers, callback=self.parseCookie)
                #if self.count >= 1000000 * (self.index + 1):
                #    print(self.categories[self.index])
                #    self.index += 1
                #    max_behot_time = 0
                #if self.index < len(self.categories):
                #    yield scrapy.Request(url=get_news_url(self.categories[self.index], max_behot_time), headers=self.headers, callback=self.parse)
                #经过测试，使用ip代理池的速度实在太慢了，不如sleep函数，1是测出来不会被封ip的速度；原来以为这里要传cookie才可以爬取，实际不需要啊；最后修改settings.py里的延迟配置就行了
                #time.sleep(1)
                #if category == 'news_fashion' or category == 'news_home':
                #    time.sleep(0.2)
                if 'next' in text.keys():
                    max_behot_time = text['next']['max_behot_time']
                    yield scrapy.Request(url=get_news_url(category, max_behot_time), headers=self.headers, callback=self.parse)

    def parseCookie(self, response):
        text = json.loads(response.body)
        if 'web_id' in text.keys():
            self.headers['cookie'] = "tt_webid=" + text['web_id']
            print(self.headers['cookie'])
            self.app_id+=1
            self.body = json.dumps({"app_id":self.app_id,"url":"https://www.toutiao.com/","user_agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36","referer":"https://www.toutiao.com/","user_unique_id":""})


