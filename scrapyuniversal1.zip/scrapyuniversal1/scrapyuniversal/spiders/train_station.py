# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
from scrapyuniversal.urls import get_train_num
import datetime as dt
import json
import re

class TrainStationSpider(scrapy.Spider):
    name = 'train_station'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(TrainStationSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
    	train_num_list = get_train_num()
    	for train_num in train_num_list:
    		url = self.start_urls[0] + train_num[0] + "/"
    		yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)            

    def parse(self, response):
        train_num = response.xpath('//div[@class="s_hd"]/span/text()')[0].extract()
        station_htmls = response.xpath('//table[@class="tb_result tb_inquiry tb_gray"]/tbody/tr')
        for station_html in station_htmls:
            station_info = station_html.xpath('./td//text()').extract()
            item = TrainStationItem()
            item['train_num'] = "'" + train_num.replace("\n", "").replace(" ", "").replace("\r", "") + "'"
            item['station_order'] = station_info[0].replace("\n", "").replace(" ", "").replace("\r", "")
            item['station_name'] = "'" + station_info[2].replace("\n", "").replace(" ", "").replace("\r", "") + "'"
            item['arrive_time'] = "'" + station_info[3].replace("\n", "").replace(" ", "").replace("\r", "") + "'"
            item['depart_time'] = "'" + station_info[4].replace("\n", "").replace(" ", "").replace("\r", "") + "'"
            item['stay_interval'] = re.findall(r"\d+", station_info[5].replace("\n", "").replace(" ", "").replace("\r", ""))[0]
            yield item
