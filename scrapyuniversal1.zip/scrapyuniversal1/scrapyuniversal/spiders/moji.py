# -*- coding: utf-8 -*-
import scrapy
from scrapyuniversal.utils import get_config
from scrapyuniversal.items import *
import datetime as dt
import json
class MojiSpider(scrapy.Spider):
    name = 'moji'

    def __init__(self, name, *args, **kwargs):
        config = get_config(name)
        self.config = config
        start_urls = config.get("start_urls")
        self.headers = config.get("settings").get("Headers")
        if start_urls:
            if start_urls.get('type') == 'static':
                self.start_urls = start_urls.get('value')
            elif start_urls.get('type') == 'dynamic': 
                self.start_urls = list(eval('urls.' + start_urls.get('method'))(*start_urls.get('args', [])))

        self.allowed_domains = config.get("allowed_domains")
        super(MojiSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        url = self.start_urls[0]
        yield scrapy.Request(url=url, headers=self.headers)

    def parse(self, response):
         weather = json.loads(response.text)['hour24']
         for w in weather:  
            item = MojiItem()
            item['table'] = 'Weather_Gz'
            item['city'] = '广州'
            
            P_date = w['Fpredict_date']
            P_hour = w['Fpredict_hour']
            item['pred_time'] = dt.datetime.strptime(str(P_date)+' '+str(P_hour)+':00','%Y-%m-%d %H:%M')
            item['pred_time'] = item['pred_time'].strftime('%Y-%m-%d %H:%M:%S')
            item['weather'] = w['Fcondition']
            item['temp'] = w['Ftemp']
            item['temp_feel'] = w['Ffeelslike']
            item['wind_level'] = w['wind_level']
            item['wind_dir'] = w['Fwdir']
            item['humidity'] = w['Fhumidity']
            yield item
